"""Robs module"""

def hello():
    print("hello from Rob's module")