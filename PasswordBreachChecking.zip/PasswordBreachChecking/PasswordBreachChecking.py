import hashlib
import getpass
import webrequest
import urllib.request
from msvcrt import getch

shouldCheckPassword = True
while shouldCheckPassword:
    shouldCheckPassword = False
    passwordToCheck = getpass.getpass('Type possibly breached password: ')
    passwordToCheck = passwordToCheck.encode(encoding='UTF-8')
    
    hashedPassword = hashlib.sha1(passwordToCheck)
    
    fullHex = hashedPassword.hexdigest().upper()
    first5Hash = fullHex[:5]
    
    withoutFirst5 = fullHex[5:]
    
    a = webrequest.webrequest()
    
    passwords = a.callPasswordApi(first5Hash)

    crackedCount = 0
    
    for password in passwords.split():    
        passwordHashedToCount = password.decode(encoding='UTF-8').split(':')
        passwordResult = passwordHashedToCount[0]
        if withoutFirst5 == passwordResult:
            crackedCount = int(passwordHashedToCount[1])
            break
    
    ending = ''
    if crackedCount > 0:
        ending = '!'
    print(f'Password cracked {crackedCount} times{ending}')

    print('Type y to check again: ', end='', flush=True) 
    key = getch()
    if key == bytes('y', 'UTF-8') or key == bytes('Y', 'UTF-8'):
        print('') 
        shouldCheckPassword = True
    