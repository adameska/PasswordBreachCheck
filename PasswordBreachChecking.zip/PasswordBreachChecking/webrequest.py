import urllib

class webrequest(object):
    """Description of class"""

    def callPasswordApi(self, first5Hash):
        r = urllib.request.urlopen(f"https://api.pwnedpasswords.com/range/{first5Hash}")
        return r.read()


